const { Graph } = require('../app/core/Graph');
const { Schema } = require('../app/core/Schema');
const { EventBus } = require('../app/core/EventBus');

describe('Core: Graph Module', () => {
  let graph;
  let eventBus;
  let schema;

  beforeEach(() => {
    eventBus = new EventBus();
    schema = new Schema();
    graph = new Graph({ eventBus, schema });

    // Mock event bus to spy on emissions
    jest.spyOn(eventBus, 'emit');

    // Register a basic schema for testing
    schema.registerEntityType({ name: 'repo', fields: { title: 'string' } });
    schema.registerRelationType({ name: 'depends_on', fields: {} });
  });

  test('should add a valid entity and emit an event', () => {
    const entity = { id: 'uuid-1', type: 'repo', data: { title: 'UEE Project' } };
    graph.addEntity(entity);

    expect(graph.getEntity('uuid-1')).toEqual(entity);
    expect(eventBus.emit).toHaveBeenCalledWith('core.graph.entity.added', { entity });
  });

  test('should fail to add an entity with an unregistered type', () => {
    const entity = { id: 'uuid-2', type: 'invalid-type', data: {} };
    expect(() => graph.addEntity(entity)).toThrow('Schema validation failed');
    expect(eventBus.emit).not.toHaveBeenCalled();
  });

  test('should create a relation between two existing entities', () => {
    const entityA = { id: 'uuid-a', type: 'repo', data: { title: 'Core' } };
    const entityB = { id: 'uuid-b', type: 'repo', data: { title: 'UI' } };
    graph.addEntity(entityA);
    graph.addEntity(entityB);

    const relation = { id: 'rel-1', type: 'depends_on', sourceId: 'uuid-a', targetId: 'uuid-b' };
    graph.addRelation(relation);

    expect(graph.getRelation('rel-1')).toEqual(relation);
    expect(eventBus.emit).toHaveBeenCalledWith('core.graph.relation.added', { relation });
  });

  test('should fail to create a relation with a non-existent entity', () => {
    const entityA = { id: 'uuid-a', type: 'repo', data: { title: 'Core' } };
    graph.addEntity(entityA);

    const relation = { id: 'rel-2', type: 'depends_on', sourceId: 'uuid-a', targetId: 'non-existent' };
    expect(() => graph.addRelation(relation)).toThrow('Target entity "non-existent" not found');
    expect(eventBus.emit).not.toHaveBeenCalledWith('core.graph.relation.added', expect.anything());
  });

  test('should remove an entity and its connected relations', () => {
    // This test is incomplete in the original file. A full implementation would be:
    const entityA = { id: 'uuid-a', type: 'repo', data: { title: 'Core' } };
    const entityB = { id: 'uuid-b', type: 'repo', data: { title: 'UI' } };
    const relation = { id: 'rel-1', type: 'depends_on', sourceId: 'uuid-a', targetId: 'uuid-b' };
    graph.addEntity(entityA);
    graph.addEntity(entityB);
    graph.addRelation(relation);

    graph.removeEntity('uuid-a');

    expect(graph.getEntity('uuid-a')).toBeUndefined();
    expect(graph.getRelation('rel-1')).toBeUndefined();
    expect(eventBus.emit).toHaveBeenCalledWith('core.graph.entity.removed', { entityId: 'uuid-a' });
    expect(eventBus.emit).toHaveBeenCalledWith('core.graph.relation.removed', { relationId: 'rel-1' });
  });
});