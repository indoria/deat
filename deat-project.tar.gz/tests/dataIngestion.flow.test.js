const { App } = require('../app/app'); // Assuming a main App class
const { GitHubAdapter } = require('../app/adapters/GitHubAdapter');
const { GitHubMapper } = require('../app/mappers/GitHubMapper');
const { MemoryStorage } = require('../app/storage/MemoryStorage');

// Mock raw API data
const mockRawGitHubData = [
  { id: 1, name: 'uee-core', full_name: 'org/uee-core', description: 'Core logic' },
  { id: 2, name: 'uee-ui', full_name: 'org/uee-ui', description: 'UI components' },
];

// Mock the fetch call used by the adapter
global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve(mockRawGitHubData),
  })
);

describe('E2E: Data Ingestion Flow', () => {
  let app;

  beforeEach(async () => {
    // Bootstrap the application in headless mode for testing
    app = new App();
    await app.init({
      app: { mode: 'headless' },
      storage: { provider: new MemoryStorage() },
      // The adapter is loaded manually in the test
    });

    // Mock the adapter to prevent real network calls but use the real mapper
    const adapter = new GitHubAdapter({ auth: { token: 'fake-token' } });
    adapter.fetchAll = jest.fn().mockResolvedValue(mockRawGitHubData); // Use mocked fetchAll
    adapter.mapper = new GitHubMapper(); // Use the real mapper

    app.loadAdapter(adapter);
  });

  test('should fetch, map, and ingest data from an adapter into the graph', async () => {
    // 1. Initial state should be an empty graph
    let graphState = app.getGraph().serialize();
    expect(graphState.entities).toHaveLength(0);

    // 2. Trigger the data loading process
    await app.getAdapter().fetchAll();

    // In a real flow, an event would trigger the graph to ingest. We'll simulate that.
    const mappedData = app.getAdapter().mapper.map(mockRawGitHubData);
    app.getGraph().load(mappedData);

    // 3. Check the final state of the graph
    graphState = app.getGraph().serialize();
    expect(graphState.entities).toHaveLength(2);

    const coreRepo = graphState.entities.find(e => e.data.title === 'uee-core');
    expect(coreRepo).toBeDefined();
    expect(coreRepo.type).toBe('repo'); // Assuming the mapper sets the type
    expect(coreRepo.data.description).toBe('Core logic');
  });
});