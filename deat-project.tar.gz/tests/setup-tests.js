// This file runs before each test file.

// Mock the global UEE object and its core components that are expected to exist.
// This prevents tests from failing due to undefined global objects and allows for spying.
beforeEach(() => {
  global.UEE = {
    eventBus: {
      emit: jest.fn(),
      on: jest.fn(),
      off: jest.fn(),
    },
    graph: {
      addEntity: jest.fn(),
      getEntity: jest.fn(),
    },
    annotation: {
      addNote: jest.fn(),
    },
    // Add other core modules as needed for your tests
  };

  // Mock LocalStorage for storage adapter tests
  const localStorageMock = (() => {
    let store = {};
    return {
      getItem: (key) => store[key] || null,
      setItem: (key, value) => (store[key] = value.toString()),
      removeItem: (key) => delete store[key],
      clear: () => (store = {}),
    };
  })();
  Object.defineProperty(window, 'localStorage', { value: localStorageMock });
});