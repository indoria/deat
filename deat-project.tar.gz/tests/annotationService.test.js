const { AnnotationService } = require('../app/services/AnnotationService');
const { EventBus } = require('../app/core/EventBus');
const { Graph } = require('../app/core/Graph');

describe('Services: AnnotationService', () => {
  let annotationService;
  let eventBus;
  let graph;

  beforeEach(() => {
    eventBus = new EventBus();
    graph = new Graph({ eventBus }); // Simplified for this test
    annotationService = new AnnotationService({ eventBus, graph });

    jest.spyOn(eventBus, 'emit');

    // Add a dummy entity to the graph to annotate
    const entity = { id: 'target-entity-1', type: 'repo', data: {} };
    graph.addEntity(entity);
  });

  test('should add a note to an existing entity', () => {
    const targetId = 'target-entity-1';
    const noteData = { type: 'note', content: 'This is a critical component.' };

    const annotation = annotationService.annotate(targetId, noteData);

    expect(annotation.targetId).toBe(targetId);
    expect(annotation.data.content).toBe(noteData.content);
    expect(annotation.id).toBeDefined();

    const annotations = annotationService.getAnnotations(targetId);
    expect(annotations).toHaveLength(1);
    expect(annotations[0]).toEqual(annotation);

    expect(eventBus.emit).toHaveBeenCalledWith('services.annotation.added', { annotation });
  });

  test('should fail to add an annotation to a non-existent entity', () => {
    const targetId = 'non-existent-entity';
    const noteData = { type: 'note', content: 'This should fail.' };

    expect(() => annotationService.annotate(targetId, noteData)).toThrow('Target entity "non-existent-entity" not found');
  });

  test('should add and remove a tag', () => {
    const targetId = 'target-entity-1';
    const tagAnnotation = annotationService.annotate(targetId, { type: 'tag', value: 'frontend' });

    expect(annotationService.getAnnotations(targetId, { type: 'tag' })[0].data.value).toBe('frontend');

    annotationService.removeAnnotation(tagAnnotation.id);
    expect(annotationService.getAnnotations(targetId, { type: 'tag' })).toHaveLength(0);
    expect(eventBus.emit).toHaveBeenCalledWith('services.annotation.removed', { annotationId: tagAnnotation.id });
  });
});