# GraphSense - Data Exploration and Analysis Tool - Universal Entity Explorer - Data Exploration and Annotation Platform - Universal Entity Explorer (UEE)

# todo

* define **public `window.UEE` APIs**
* design **event namespaces & payload schemas**
* write **GitHub canonical schema**
* or create a **v0 → v1 execution roadmap**