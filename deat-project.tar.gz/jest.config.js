/** @type {import('jest').Config} */
const config = {
  verbose: true,
  testEnvironment: 'jsdom',
  rootDir: './', // The root of your project is the current directory
  testMatch: [
    '<rootDir>/tests/**/*.test.js'
  ],
  setupFilesAfterEnv: ['<rootDir>/tests/config/setup-tests.js'],
  moduleNameMapper: {
    // If you use aliases in your project, map them here
    // e.g., '^@core/(.*)$': '<rootDir>/src/core/$1'
  },
  collectCoverage: true,
  coverageDirectory: '<rootDir>/coverage',
};

module.exports = config;