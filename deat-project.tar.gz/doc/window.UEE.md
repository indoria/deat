Awesome, this is the **capstone API** of the whole system.
Below is a **complete, stable, public-facing API** exposed as:

```js
window.UEE
```

This API is:

* **headless-first**
* **console-usable**
* **adapter / UI agnostic**
* **event-driven**
* **version-aware**
* **future-safe**

Think of this as the **contract between the system and the outside world**.

---

# 🌐 `window.UEE` — Public System API

```js
window.UEE = {
  core,
  graph,
  schema,
  query,
  annotation,
  versioning,
  cassette,
  storage,
  sync,
  adapters,
  serializers,
  events,
  replay,
  ui,        // optional helpers, no hard dependency
  utils
}
```

Each namespace is detailed below.

---

## 1️⃣ Core / Lifecycle

### `UEE.core`

```js
UEE.core.init(options?)
UEE.core.reset()
UEE.core.destroy()
UEE.core.status()
```

**Examples**

```js
UEE.core.init({ offline: true })
UEE.core.status() // { online, activeVersion, activeBranch }
```

---

## 2️⃣ Graph API (Primary Manipulation Layer)

### `UEE.graph`

```js
UEE.graph.create(schemaId?)
UEE.graph.load(jsonOrHtml)
UEE.graph.serialize(format = "json")

UEE.graph.addEntity(entity)
UEE.graph.updateEntity(entityId, patch)
UEE.graph.removeEntity(entityId)

UEE.graph.addRelation(relation)
UEE.graph.updateRelation(relationId, patch)
UEE.graph.removeRelation(relationId)

UEE.graph.enterSubgraph(entityId)
UEE.graph.exitSubgraph()

UEE.graph.getEntity(id)
UEE.graph.getRelation(id)
UEE.graph.getActiveGraph()
```

**Entity shape**

```js
{
  id?: UUID,
  type: string,
  metadata: { title, description?, tags? }
}
```

---

## 3️⃣ Schema API

### `UEE.schema`

```js
UEE.schema.load(schemaObject)
UEE.schema.getActive()
UEE.schema.addEntityType(name, definition)
UEE.schema.addRelationType(name, definition)
UEE.schema.validateGraph()
```

**Example**

```js
UEE.schema.addEntityType("microservice", {
  requiredMetadata: ["title"],
  optionalMetadata: ["tags"]
})
```

---

## 4️⃣ Query API

### `UEE.query`

```js
UEE.query.where(condition)
UEE.query.diff(oldVersionId, newVersionId)
UEE.query.shortestPath(fromId, toId)
UEE.query.execute()
```

**Example**

```js
UEE.query
  .where(type="repository")
  .and(tag="frontend")
  .execute()
```

---

## 5️⃣ Annotation API

### `UEE.annotation`

```js
UEE.annotation.addNote(targetId, content)
UEE.annotation.updateNote(noteId, content)
UEE.annotation.removeNote(noteId)

UEE.annotation.addTag(label, options?)
UEE.annotation.deleteTag(tagId)

UEE.annotation.attachTag(tagId, targetId)
UEE.annotation.detachTag(tagId, targetId)

UEE.annotation.setFlag(targetId, flag, value)
UEE.annotation.unsetFlag(targetId, flag)

UEE.annotation.getAnnotations(targetId)
```

---

## 6️⃣ Versioning & Branching

### `UEE.versioning`

```js
UEE.versioning.createVersion(label?)
UEE.versioning.switchVersion(versionId)

UEE.versioning.createBranch(fromVersionId)
UEE.versioning.switchBranch(branchId)

UEE.versioning.getVersions()
UEE.versioning.getBranches()
```

---

## 7️⃣ Cassette (Narrative Player)

### `UEE.cassette`

```js
UEE.cassette.create(versionId, frames)
UEE.cassette.update(cassetteId, patch)
UEE.cassette.delete(cassetteId)

UEE.cassette.play(cassetteId)
UEE.cassette.pause(cassetteId)
UEE.cassette.stop(cassetteId)
UEE.cassette.seek(cassetteId, frameIndex)

UEE.cassette.setSpeed(cassetteId, multiplier)

UEE.cassette.get(cassetteId)
UEE.cassette.list(versionId)
```

**Frame**

```js
{
  entities: UUID[],
  relations: UUID[],
  durationMs: number,
  action: string
}
```

---

## 8️⃣ Storage API

### `UEE.storage`

```js
UEE.storage.use(providerName)
UEE.storage.save()
UEE.storage.load()
UEE.storage.status()
```

---

## 9️⃣ Sync / Offline Control

### `UEE.sync`

```js
UEE.sync.goOffline()
UEE.sync.goOnline()
UEE.sync.sync()
UEE.sync.isOnline()
```

---

## 🔌 10️⃣ Adapters (External Data Sources)

### `UEE.adapters`

```js
UEE.adapters.list()
UEE.adapters.use(name)

UEE.adapters.fetch(options)
UEE.adapters.refresh()
```

**Example**

```js
UEE.adapters.use("github")
UEE.adapters.fetch({ org: "openai" })
```

---

## 🔄 11️⃣ Serializers

### `UEE.serializers`

```js
UEE.serializers.toJSON()
UEE.serializers.fromJSON(json)

UEE.serializers.toHTML()
UEE.serializers.fromHTML(html)
```

---

## 🔔 12️⃣ Events API

### `UEE.events`

```js
UEE.events.on(eventName, handler)
UEE.events.off(eventName, handler)
UEE.events.once(eventName, handler)

UEE.events.emit(name, payload)
UEE.events.list()
```

**Example**

```js
UEE.events.on("core.graph.entity.added", e => console.log(e))
```

---

## ⏪ 13️⃣ Replay API

### `UEE.replay`

```js
UEE.replay.start(options?)
UEE.replay.stop()

UEE.replay.scrubTo(eventIndex)
UEE.replay.play()
UEE.replay.pause()

UEE.replay.status()
```

---

## 🖥️ 14️⃣ UI Helpers (Optional, Non-Core)

### `UEE.ui`

```js
UEE.ui.setViewMode(mode)
UEE.ui.highlightEntity(id)
UEE.ui.clearHighlight()
```

> UI helpers only emit events — they do not mutate core state.

---

## 🛠️ 15️⃣ Utilities

### `UEE.utils`

```js
UEE.utils.uuid()
UEE.utils.now()
UEE.utils.clone(obj)
UEE.utils.validateSchema(schema)
```

---

# 🔐 API Guarantees

* **Stable namespaces**
* **No hidden globals**
* **Every mutation emits events**
* **Safe to use from DevTools**
* **Replay-compatible**
* **Version-aware by default**

---

# 🧪 Example: Full Console Workflow

```js
UEE.core.init()

UEE.adapters.use("github")
UEE.adapters.fetch({ user: "octocat" })

UEE.query.where(type="repository").execute()

UEE.annotation.addNote(repoId, "Critical frontend repo")

UEE.versioning.createVersion("after-analysis")

UEE.cassette.create(UEE.core.status().activeVersion, [
  { entities: [repoId], relations: [], durationMs: 2000, action: "highlight" }
])

UEE.cassette.play(cassetteId)
```