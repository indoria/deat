export const GitHubSchema = {
  id: "schema.github.v1",
  version: "1.0.0",

  entities: {
    account: {
      description: "GitHub user or organization",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags", "icon"],
    },

    repository: {
      description: "Git repository",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags", "archived", "size"],
    },

    branch: {
      description: "Git branch",
      requiredMetadata: ["title"],
      optionalMetadata: ["tags"],
    },

    commit: {
      description: "Commit object",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags"],
    },

    directory: {
      description: "Directory in repository",
      requiredMetadata: ["title"],
      optionalMetadata: ["tags"],
    },

    file: {
      description: "File in repository",
      requiredMetadata: ["title"],
      optionalMetadata: ["tags", "size"],
    },

    issue: {
      description: "GitHub issue",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags", "state"],
    },

    pull_request: {
      description: "Pull request",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags", "state"],
    },

    collaborator: {
      description: "GitHub user",
      requiredMetadata: ["title"],
      optionalMetadata: ["tags"],
    },

    team: {
      description: "Organization team",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags"],
    },

    workflow: {
      description: "GitHub Actions workflow",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags"],
    },

    release: {
      description: "Repository release",
      requiredMetadata: ["title"],
      optionalMetadata: ["description", "tags"],
    },

    tag_ref: {
      description: "Git tag reference",
      requiredMetadata: ["title"],
      optionalMetadata: ["tags"],
    },
  },

  relations: {
    OWNS: {
      from: "account",
      to: "repository",
    },

    HAS_BRANCH: {
      from: "repository",
      to: "branch",
    },

    DEFAULT_BRANCH: {
      from: "repository",
      to: "branch",
      cardinality: "one-to-one",
    },

    CONTAINS: {
      from: ["repository", "directory"],
      to: ["directory", "file"],
    },

    HAS_ACCESS: {
      from: "collaborator",
      to: "repository",
      metadata: ["permission"],
    },

    MEMBER_OF: {
      from: "collaborator",
      to: "account",
    },

    CREATED_BY: {
      from: ["commit", "issue", "pull_request"],
      to: "collaborator",
    },

    MERGES_INTO: {
      from: "pull_request",
      to: "branch",
    },

    AUTOMATES: {
      from: "workflow",
      to: "repository",
    },

    TAGGED_AS: {
      from: "repository",
      to: "tag_ref",
    },

    RELEASED_AS: {
      from: "release",
      to: "tag_ref",
    },

    REFERENCES: {
      from: ["issue", "pull_request"],
      to: ["issue", "pull_request"],
    },
  }
};
